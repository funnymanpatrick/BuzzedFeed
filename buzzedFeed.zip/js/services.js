angular.module('app.services', [])


//TODO: Have ids for each so not keying by name
//Hashmap?

.factory('GetDrinks', [function() {
	return {
		drinks: [
			{name: 'Gin and Tonic', alcohol: ['Gin'], mixers: ['Tonic']},
			{name: 'Dark and Stormy', alcohol: ['Rum'], mixers: ['Ginger Beer']},
			{name: 'Rum and Coke', alcohol: ['Rum'], mixers: ['Cola']},
			{name: 'Bloody Mary', alcohol: ['Vodka'], mixers: ['Tomato Juice']},
			{name: 'Moscow Mule', alcohol: ['Vodka'], mixers: ['Ginger Beer', 'Lime Juice']},
			{name: 'Screwdriver', alcohol: ['Vodka'], mixers: ['Orange Juice']},
			{name: 'Long Island Iced Tea', alcohol: ['Gin', 'Tequila', 'Vodka', 'Rum'], mixers: ['Lemon Juice']}
		]
	};
}])

.factory('GetAlcohol', [function(){
	return {
		alcohol: [
			{name: 'Vodka'},
			{name: 'Rum'},
			{name: 'Gin'},
			{name: 'Tequila'},
			{name: 'Whiskey'}
		]
	}
}])

.factory('GetMixers', [function(){
	return {
		mixers: [
			{name: 'Tonic Water'},
			{name: 'Ginger Beer'},
			{name: 'Cola'},
			{name: 'Tomato Juice'},
			{name: 'Orange Juice'},
			{name: 'Red Bull'},
			{name: 'Lemon Juice'},
			{name: 'Lime Juice'}
		]
	}
}]);