angular.module('app.controllers', [])
  
.controller('stockCtrl', ['$scope', '$stateParams', 'GetDrinks', 'GetAlcohol', 'GetMixers',
function ($scope, $stateParams, GetDrinks, GetAlcohol, GetMixers) {
	$scope.stock = [];

	$scope.all_drinks = GetDrinks.drinks;
	$scope.all_alcohol = GetAlcohol.alcohol;
	$scope.all_mixers = GetMixers.mixers;

	$scope.searchedAlcohol = '';

	$scope.searchAlcohol = function(){
		toSearch = document.getElementById("searchedAlcohol").value;

		for (i=0; i<$scope.all_alcohol.length; i++){
			if($scope.all_alcohol[i].name.toUpperCase() == toSearch.toUpperCase()){
				$scope.stock.push($scope.all_alcohol[i].name);
			}
		}
	};

}])
   
.controller('drinksCtrl', ['$scope', '$stateParams', 'GetDrinks', 'GetAlcohol', 'GetMixers',
function ($scope, $stateParams) {

	$scope.all_drinks = GetDrinks.drinks;
	$scope.all_alcohol = GetAlcohol.alcohol;
	$scope.all_mixers = GetMixers.mixers;

}])
   
.controller('recommendationsCtrl', ['$scope', '$stateParams',
function ($scope, $stateParams) {


}])
    